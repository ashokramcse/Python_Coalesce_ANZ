from django.shortcuts import render
from django.http.response import HttpResponse
from .formsdemo import Deviceform
from django.http import HttpResponseRedirect
# Create your views here.

def home(request):
    message="""<h1 align='center' style='color:blue'>
    Welcome to ANZ Lab</h1>"""
    return HttpResponse(message)


def device(request):
    if request.method == 'POST':
         form = Deviceform(request.POST)
         if form.is_valid():
             global ipaddr,macddr
             ipaddr=form.cleaned_data['ipaddress']
             macaddr=form.cleaned_data['macaddress']
             return HttpResponseRedirect('/success/')
    else:
        form = Deviceform()
    return render(request, 'device.html', {'form': form})
         
         
def success(request):
    message=  "<h4> Device Information Received<br/>%s </h4>" %ipaddr
            
    return HttpResponse(message)
           
    
         
         