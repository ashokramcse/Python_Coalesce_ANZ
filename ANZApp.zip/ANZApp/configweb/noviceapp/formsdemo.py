'''
Created on 27-Jun-2017

@author: BALASUBRAMANIAM
'''
from django import forms
class Deviceform(forms.Form):
   ipaddress=forms.CharField(label="IP Address",max_length=16, min_length=10)
   macaddress=forms.CharField(label="Mac Address", max_length=24, min_length=10)
